document.querySelectorAll('.buy-button').forEach(button => {
    button.addEventListener('click', () => {
        alert('Thank you for your purchase!');
    });
});